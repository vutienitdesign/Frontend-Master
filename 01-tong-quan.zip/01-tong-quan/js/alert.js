// JavaScript Document
function message(){
	alert("Hello World");
}